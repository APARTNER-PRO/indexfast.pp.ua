<?php
// ══════════════════════════════════════════════
//  expire_subscriptions.php
//  Запускати через cron: щодня о 00:05
//  Cron: 5 0 * * * php /home/USER/worker/expire_subscriptions.php
//
//  Що робить:
//  1. Знаходить юзерів з простроченим plan_expires_at
//  2. Скидає їх план на 'start'
//  3. Надсилає email-сповіщення
//  4. Логує дії
// ══════════════════════════════════════════════

$root = dirname(__DIR__) . '/api';
require_once $root . '/config.php';
require_once $root . '/db.php';
require_once $root . '/helpers.php';

// ── Захист від паралельного запуску
$lockFile = sys_get_temp_dir() . '/indexfast_expire.lock';
if (file_exists($lockFile) && (time() - filemtime($lockFile)) < 3600) {
    echo "[expire] Already running, skip.\n";
    exit(0);
}
file_put_contents($lockFile, getmypid());

function log_msg(string $msg): void {
    echo '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n";
}

log_msg('Expire subscriptions started.');

try {
    // ── 1. Знаходимо всі прострочені підписки (не start план)
    $expired = DB::all(
        "SELECT id, email, name, plan, plan_expires_at, paddle_sub_id
         FROM users
         WHERE plan != 'start'
           AND plan_expires_at IS NOT NULL
           AND plan_expires_at < NOW()
           AND is_active = 1",
    );

    log_msg("Found " . count($expired) . " expired subscription(s).");

    foreach ($expired as $user) {
        $userId    = (int)$user['id'];
        $oldPlan   = $user['plan'];
        $expiresAt = $user['plan_expires_at'];

        // ── 2. Скидаємо план на start
        DB::exec(
            "UPDATE users
             SET plan = 'start',
                 plan_expires_at  = NULL,
                 plan_started_at  = NULL,
                 paddle_sub_id    = NULL,
                 updated_at       = NOW()
             WHERE id = ?",
            [$userId]
        );

        log_msg("User #{$userId} ({$user['email']}): {$oldPlan} → start (expired {$expiresAt})");

        // ── 3. Email-сповіщення
        try {
            sendExpiredEmail($user['email'], $user['name'], $oldPlan);
        } catch (Throwable $e) {
            log_msg("Email failed for #{$userId}: " . $e->getMessage());
        }
    }

    // ── 4. Нагадування за 3 дні до закінчення
    $expiringSoon = DB::all(
        "SELECT id, email, name, plan, plan_expires_at
         FROM users
         WHERE plan != 'start'
           AND plan_expires_at IS NOT NULL
           AND plan_expires_at BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 3 DAY)
           AND is_active = 1",
    );

    log_msg("Found " . count($expiringSoon) . " subscription(s) expiring in 3 days.");

    foreach ($expiringSoon as $user) {
        try {
            sendExpiringEmail($user['email'], $user['name'], $user['plan'], $user['plan_expires_at']);
            log_msg("Reminder sent to #{$user['id']} ({$user['email']}), expires {$user['plan_expires_at']}");
        } catch (Throwable $e) {
            log_msg("Reminder failed for #{$user['id']}: " . $e->getMessage());
        }
    }

} catch (Throwable $e) {
    log_msg("ERROR: " . $e->getMessage());
} finally {
    @unlink($lockFile);
    log_msg('Done.');
}

// ════════════════════════════════════════
//  Email шаблони
// ════════════════════════════════════════

function sendExpiredEmail(string $to, string $name, string $plan): void {
    $planLabel = match($plan) {
        'pro'        => 'PRO',
        'agency'     => 'Агенція',
        'enterprise' => 'Enterprise',
        default      => $plan,
    };

    $html = Mailer::send($to, "Ваша підписка {$planLabel} завершилась", buildExpiredHtml($name, $planLabel));
}

function buildExpiredHtml(string $name, string $planLabel): string {
    $renewUrl = APP_URL . '/#pricing';
    return <<<HTML
    <!DOCTYPE html><html><head><meta charset="UTF-8"></head>
    <body style="background:#050508;margin:0;padding:20px;font-family:Arial,sans-serif">
    <table width="100%" cellpadding="0" cellspacing="0">
    <tr><td align="center">
    <table width="520" cellpadding="0" cellspacing="0"
      style="background:#111119;border-radius:16px;border:1px solid rgba(255,255,255,0.08);overflow:hidden;max-width:520px">
    <tr><td style="background:#050508;padding:20px 32px;border-bottom:1px solid rgba(255,255,255,0.06)">
      <span style="font-size:20px;font-weight:800;color:#eeeef6;font-family:Arial,sans-serif">
        Index<span style="color:#00ff88">Fast</span>
      </span>
    </td></tr>
    <tr><td style="padding:32px;color:#c8c8d8;font-size:15px;line-height:1.7">
      <p>Привіт, <strong style="color:#eeeef6">{$name}</strong>!</p>
      <p>Ваша підписка <strong style="color:#ffd060">{$planLabel}</strong> завершилась.
         Акаунт переведено на безкоштовний план Старт (20 URL/день).</p>
      <p>Щоб продовжити користуватися повним функціоналом — поновіть підписку:</p>
      <p style="text-align:center;margin:28px 0">
        <a href="{$renewUrl}"
           style="background:#00ff88;color:#050508;padding:13px 28px;border-radius:100px;
                  text-decoration:none;font-weight:700;font-size:15px">
          Поновити підписку →
        </a>
      </p>
      <p style="font-size:13px;color:#555570">
        Ваші сайти і логи збережені. Щойно поновите — все відновиться автоматично.
      </p>
    </td></tr>
    <tr><td style="padding:16px 32px;border-top:1px solid rgba(255,255,255,0.06);
                   font-size:12px;color:#555570;text-align:center">
      © IndexFast · <a href="https://indexfast.pp.ua" style="color:#555570">indexfast.pp.ua</a>
    </td></tr>
    </table>
    </td></tr>
    </table>
    </body></html>
    HTML;
}

function sendExpiringEmail(string $to, string $name, string $plan, string $expiresAt): void {
    $planLabel = match($plan) {
        'pro'        => 'PRO',
        'agency'     => 'Агенція',
        'enterprise' => 'Enterprise',
        default      => $plan,
    };
    $date = date('d.m.Y', strtotime($expiresAt));
    $renewUrl = APP_URL . '/#pricing';

    $html = <<<HTML
    <!DOCTYPE html><html><head><meta charset="UTF-8"></head>
    <body style="background:#050508;margin:0;padding:20px;font-family:Arial,sans-serif">
    <table width="100%" cellpadding="0" cellspacing="0">
    <tr><td align="center">
    <table width="520" cellpadding="0" cellspacing="0"
      style="background:#111119;border-radius:16px;border:1px solid rgba(255,255,255,0.08);overflow:hidden;max-width:520px">
    <tr><td style="background:#050508;padding:20px 32px;border-bottom:1px solid rgba(255,255,255,0.06)">
      <span style="font-size:20px;font-weight:800;color:#eeeef6">Index<span style="color:#00ff88">Fast</span></span>
    </td></tr>
    <tr><td style="padding:32px;color:#c8c8d8;font-size:15px;line-height:1.7">
      <p>Привіт, <strong style="color:#eeeef6">{$name}</strong>!</p>
      <p>⏰ Ваша підписка <strong style="color:#ffd060">{$planLabel}</strong> завершується
         <strong style="color:#eeeef6">{$date}</strong> — через 3 дні.</p>
      <p>Поновіть підписку щоб не втратити доступ до:</p>
      <ul style="color:#c8c8d8;padding-left:20px">
        <li>Необмеженої кількості URL на день</li>
        <li>Автоматичного запуску за розкладом</li>
        <li>Пріоритетної обробки в черзі</li>
      </ul>
      <p style="text-align:center;margin:28px 0">
        <a href="{$renewUrl}"
           style="background:#00ff88;color:#050508;padding:13px 28px;border-radius:100px;
                  text-decoration:none;font-weight:700;font-size:15px">
          Поновити підписку →
        </a>
      </p>
    </td></tr>
    <tr><td style="padding:16px 32px;border-top:1px solid rgba(255,255,255,0.06);
                   font-size:12px;color:#555570;text-align:center">
      © IndexFast · <a href="https://indexfast.pp.ua" style="color:#555570">indexfast.pp.ua</a>
    </td></tr>
    </table>
    </td></tr>
    </table>
    </body></html>
    HTML;

    Mailer::send($to, "⏰ Ваша підписка {$planLabel} завершується {$date}", $html);
}
